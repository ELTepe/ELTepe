# Jorge Macias personal web pages

### Hello World! 👋 :octocat:	
> *Sad news, world never says hello back* <br/>
> *People always say "hello world!" But never "how are you world?🌎"*

I´m Ulmo! If u want to know more about me check below.  
Visit [my online CV](https://ulmomacias.github.io).
You can visit [my interactive bio](https://ulmomacias.github.io/Bio.html) to learn more about me


# ![me](https://media2.giphy.com/media/QyhbMNsMlmR5I1kgGn/giphy.gif)

🔭 I’m currently studying two BS: Computer Science, Data Science <br/>
📫 How to reach me: You can reach me on [linkdIn](https://www.linkedin.com/in/ulmo-macias/), or email at jorgemacias(at)ciencias.unam.mx


## Interactive Bio

Done using [revealjs](https://revealjs.com)
### Reveal.js

reveal.js is an open source HTML presentation framework. It enables anyone with a web browser to create fully featured and beautiful presentations for free. [Check out the live demo](https://revealjs.com/).
### Documentation
The full reveal.js documentation is available at [revealjs.com](https://revealjs.com).
### License

MIT licensed

Copyright (C) 2011-2020 Hakim [El Hattab](https://hakim.se)

## CV Template


Free Bootstrap 4 Resume/CV Template for developers
Theme name: Pillar

Theme version: v1.0.1

Release Date: 23 July 2018

Author: Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

### Contact
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Twitter: @3rdwave_themes

### License: 
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/

If you'd like to use the template without the attribution, you can buy the commercial license via our website: https://themes.3rdwavemedia.com/
